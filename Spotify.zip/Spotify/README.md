# This is the template of the spotify project
